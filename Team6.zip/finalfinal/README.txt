DEPENDENCIES REQUIRED:
    tkinter
    socket
    flask
    flask_jwt_extended
    hashlib
    binascii
    pymongo
    Crypto
    requests

HOW TO RUN THE PROJECT:
0-Download openssl and make a certificate using the links in the report to guide you 
if any problems encountered contact us and use the common name in our case is 127.0.0.1 for 
creating the certificate after creating your own key.pem and cert.pem remove ours from the zip folder
1- run: pip install <dependency_name>
2- run the backend.py
3- run the trial2.py
4- sign up for the first time you use the app
5- login with the credintials you used for the sign up
6- start adding friends to the chat with their username
7- to start another instance of the front end, 
   copy the frontend file to another path and run it and apply 
   the same procedure for the signup and login 
8- if you closed the front-end and run it again, 
   you don't need to login as the token will do the job


NOTE: For communication messaging the two users have to add each other not only one user

