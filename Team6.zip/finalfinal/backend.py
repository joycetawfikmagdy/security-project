from flask import Flask
from flask import request
import hashlib, binascii, os
import json, random, string
from flask import Response
from pymongo import MongoClient
from flask_jwt_extended import (JWTManager, create_access_token,)
client1 = MongoClient("mongodb://joyce.tawfik:Godislove*1@ds145486.mlab.com:45486/security")
db = client1['security']
users= db['users']

secret = ''.join(random.choices(string.ascii_uppercase + string.digits, k=20))
token_salt = hashlib.sha256(os.urandom(60)).hexdigest().encode('ascii')

app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = secret
jwt = JWTManager(app)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
	dataDict = json.loads(request.data)
	username = dataDict.get('username')
	password = dataDict.get('password')
	publickey = dataDict.get('publickey')
	ipaddrs= request.remote_addr
	#decrypting goes here
	return signupp(username,password,ipaddrs,publickey)
@app.route('/test')
def test():
	
	return "test"
@app.route("/login", methods=['GET', 'POST'])
def login():

	userfound=False
	succ=False
	dataDict = json.loads(request.data)
	username = dataDict.get('username')
	password=  dataDict.get('password')
	
	ipaddrs= request.remote_addr
	#decrypting goes here
	users = db.users.find({"username": username}, no_cursor_timeout=True)
	for items in users:
		userfound=True
		succ=verify_password(items["password"], password)
		if succ:
			access_token = create_access_token(identity=username)
			hashed_token = hash_token(access_token)
			db.users.update_one({"username": username}, {
            "$set": {
                "ip": ipaddrs, "token": hashed_token}})
		
			response = {"succ": succ, "userfound": userfound, "token": access_token}
		else:
			response = {"succ": succ, "userfound": userfound}
	js = json.dumps(response)
	resp = Response(js, status=200, mimetype='application/json')
	return resp 


@app.route("/logintoken", methods=['GET', 'POST'])
def logintoken():

	userfound = False
	succ = False
	dataDict = json.loads(request.data)
	token = dataDict.get('token')
	ipaddrs = request.remote_addr
	#decrypting goes here
	hashed_token = hash_token(token)
	users = db.users.find({"token": hashed_token}, no_cursor_timeout=True)
	user = users[0]
	if user:
		userfound = True
		db.users.update_one({"token": hashed_token}, {
                            "$set": {
                                "ip": ipaddrs}}, upsert=True)

	response = {"userfound": userfound, "username":user["username"]}
	js = json.dumps(response)
	resp = Response(js, status=200, mimetype='application/json')
	return resp

@app.route("/nametoport", methods=['GET', 'POST'])
def nametoport():
	dataDict = json.loads(request.data)
	userfound=False
	username = dataDict.get('username')
	
	
	
	port=""
	#decrypting goes here
	users = db.users.find({"username": username}, no_cursor_timeout=True)
	for items in users:
		userfound=True
		port=items["port"]
		

	response={"port":port,"userfound":userfound}
	js = json.dumps(response)
	resp = Response(js, status=200, mimetype='application/json')
	return resp 

@app.route("/publickeyreq", methods=['GET', 'POST'])
def publickeyrec():
	dataDict = json.loads(request.data)
	userfound=False
	username = dataDict.get('username')
	
	
	
	publicKey=""
	#decrypting goes here
	users = db.users.find({"username": username}, no_cursor_timeout=True)
	for items in users:
		userfound=True
		publicKey=items["publickey"]
		

	response={"publickey":publicKey,"userfound":userfound}
	js = json.dumps(response)
	resp = Response(js, status=200, mimetype='application/json')
	return resp 

def hash_password(password):
    """Hash a password for storing."""
    salt = hashlib.sha256(os.urandom(60)).hexdigest().encode('ascii')
    pwdhash = hashlib.pbkdf2_hmac('sha512', password.encode('utf-8'), 
                                salt, 100000)
    pwdhash = binascii.hexlify(pwdhash)
    return (salt + pwdhash).decode('ascii')

def verify_password(stored_password, provided_password):
    """Verify a stored password against one provided by user"""
    salt = stored_password[:64]
    stored_password = stored_password[64:]
    pwdhash = hashlib.pbkdf2_hmac('sha512', 
                                  provided_password.encode('utf-8'), 
                                  salt.encode('ascii'), 
                                  100000)
    pwdhash = binascii.hexlify(pwdhash).decode('ascii')
    return pwdhash == stored_password


def hash_token(token):
    """Hash a token word for storing."""
    token_hashed = hashlib.pbkdf2_hmac('sha512', token.encode('utf-8'), 
                                token_salt, 100000)
    token_hashed = binascii.hexlify(token_hashed)
    return (token_hashed).decode('ascii')

def signupp(username,password,ipaddrs,publicKey):
	found=False
	count=db.users.find().count()
	port=8090+count
	users = db.users.find({"username": username}, no_cursor_timeout=True)

	for items in users:
		found=True


	if not found:
		db.users.update_one({"username": username}, {
			"$set": {
			"username": username,
			"password":hash_password(password),
			"port":port,
			"publickey":publicKey,
			"token":"",
			"ip":ipaddrs}}, upsert=True)

	response={"found": found}
	js = json.dumps(response)
	resp = Response(js, status=200, mimetype='application/json')
	return resp    
        
if __name__ == '__main__':
    app.run(host='localhost',debug=True,threaded=True,ssl_context=('cert.pem', 'key.pem'))

